import java.util.*;
import java.io.*;

public class B {

   public static void main (String [] args) throws Exception {
      //B1-102, B2-339, B3-15287
      Scanner sc = new Scanner(new File("B1.in"));
      int N = sc.nextInt();
      int [][] grid = new int[N][N];
      for (int k=0; k<N; k++)
         for (int j=0; j<N; j++)
            grid[k][j]=sc.nextInt();
      int [][] dp = new int[N][N];
      for (int k=0; k<N; k++)
         Arrays.fill(dp[k], 9999999);
      dp[0][0]=0;
      for (int k=0; k<N; k++)
         for (int j=0; j<N; j++) { 
            //propagate down
            if (k+1<N) {
               if (grid[k+1][j]<=grid[k][j]) 
                  dp[k+1][j]=Math.min(dp[k+1][j], dp[k][j]+1); //equal or lower
               else 
                  dp[k+1][j]=Math.min(dp[k+1][j], dp[k][j]+grid[k+1][j]-grid[k][j]+1); //need extra energy
            }   
            //propagate right
            if (j+1<N) {
               if (grid[k][j+1]<=grid[k][j])
                  dp[k][j+1]=Math.min(dp[k][j+1], dp[k][j]+1); 
               else
                  dp[k][j+1]=Math.min(dp[k][j+1], dp[k][j]+grid[k][j+1]-grid[k][j]+1); 
            }
         }
      if (dp[N-1][N-1]==9999999)
         System.out.println("Not Possible");
      else
         System.out.println(dp[N-1][N-1]);
   }
}