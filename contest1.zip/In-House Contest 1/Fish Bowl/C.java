import java.util.*;
import java.io.*;

public class C {
   
   static int [][] avoid;
   public static void main (String [] args) throws Exception {
      //C1-15120, C2-8, C3-2916
      Scanner sc = new Scanner(new File("C3.in"));
      int N = sc.nextInt();
      avoid = new int[N][2];
      for (int k=0; k<N; k++) {
         avoid[k][0]=sc.nextInt();
         avoid[k][1]=sc.nextInt();
      }
      gen(0);
      System.out.println(count);
   }
   static int count = 0;
   static int [] arrange = new int[9]; //stores a generated permutation
   static boolean [] used = new boolean[10]; //has a number in [1,9] been used
   public static void gen(int pos) {
      if (pos==9) { //end
         if (check())
            count++;
         return;
      }   
      for (int i=1; i<=9; i++) { //try every number
         if (!used[i]) {
            arrange[pos]=i;
            used[i]=true;
            gen(pos+1);
            used[i]=false;
            arrange[pos]=0;
         }
      }
   }
   public static boolean check() {
      int [] loc = new int[10]; //location of every fish 1...9
      for (int k=0; k<9; k++)
         loc[arrange[k]]=k;
      for (int k=0; k<avoid.length; k++) //for every constraint 
         if (loc[avoid[k][1]]>loc[avoid[k][0]]) //second fish must be behind first
            return false;
      return true;
   }
}