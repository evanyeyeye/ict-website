import java.util.*;
import java.io.*;

public class A {

   public static void main (String [] args) throws Exception {
      //A1-1000115 1000116, A2-949957 949958, A3-25 26
      Scanner sc = new Scanner(new File("A3.in"));
      int N = sc.nextInt();
      int [] w = new int[N];
      for (int k=0; k<N; k++)
         w[k]=sc.nextInt();
      long [] ps = new long[N+1];
      for (int k=1; k<=N; k++) //prefix sums
         ps[k]=ps[k-1]+w[k-1];  
      long min = Long.MAX_VALUE;
      int index = -1;
      for (int k=0; k<=N; k++)
         if (Math.abs(ps[N]-2*ps[k])<min) { //difference of the left and right weight sums
            min = Math.abs(ps[N]-2*ps[k]);
            index = k;
         }
      System.out.println(index+" "+(index+1));
   }
}